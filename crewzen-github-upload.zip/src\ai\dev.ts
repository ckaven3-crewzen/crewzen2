import { config } from 'dotenv';
config();

import '@/ai/flows/analyze-server-logs.ts';
import '@/ai/flows/generate-config.ts';
