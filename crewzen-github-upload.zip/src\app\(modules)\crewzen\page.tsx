import { redirect } from 'next/navigation';

export default function CrewZen() {
  // Redirect to CrewZen dashboard
  redirect('/crewzen/dashboard');
} 