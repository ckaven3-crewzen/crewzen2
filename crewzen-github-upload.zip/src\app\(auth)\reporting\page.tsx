"use client";

import ReportingPage from '@/app/(modules)/crewzen/reporting/page';

export default function Reporting() {
  return <ReportingPage />;
}