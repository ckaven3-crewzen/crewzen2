import { redirect } from 'next/navigation';

export default function Marketplace() {
  redirect('/connectzen/businessMarketplacePage');
} 