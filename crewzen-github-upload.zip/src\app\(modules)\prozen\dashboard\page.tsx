import { redirect } from 'next/navigation';

export default function ProZenDashboard() {
  // Redirect to main ProZen page for now
  redirect('/prozen');
} 